"以类的形式描述点坐标"
class Point:
  row=0
  col=0
  def __init__(self,row,col):
    self.row=row
    self.col=col
  def copy(self):
    return Point(row=self.row,col=self.col)


import pygame
import random
import time
pygame.init()

"初始化游戏设置"
W = 800
H = 600
ROW= 30
COL= 40
size= (W,H)                                    #游戏画面screen的大小
screen= pygame.display.set_mode(size) 

#初始化蛇头与身子的的坐标
head=Point(row=int(ROW/2),col=int(COL/2))
body=[
  Point(row=head.row,col=head.col+1),
  Point(row=head.row,col=head.col+2),
  Point(row=head.row,col=head.col+3),
]
#初始化颜色配置，因为希望刚进游戏时各元素不显示，故初始化为白色，若修改颜色请在循环中修改
bg_color=(255,255,255)
body_color=(255,255,255)
head_color=(255,255,255)
food_color=(255,255,255)
food_judge=0                     #判定食物种类的标记

"随机生成食物的函数实现"
def gen_food():
  while 1 :
    flag =False
    food=Point(row=random.randint(1,ROW-2),col=random.randint(1,COL-2))
    if food ==head:
      flag=True
    for Body in body:
      if food == Body:
        flag =True
    if flag ==False:
      return food
food = gen_food()
    
#初始化分数，实现显示分数的函数
score=0
def show_score():
  font =pygame.font.Font(None,32)
  text=f"Score: {score}"
  score_render = font.render(text,True,(0,255,0))
  screen.blit (score_render,(10,10))
  

#用来绘制文字的函数，可直接调用
def show_text(text,type,size,color,x,y):
  my_font = pygame.font.SysFont(type, size)
  my_font_render = my_font.render(text,True,color)
  screen.blit (my_font_render,(x,y))

"绘制各元素图像的函数实现"
def rect(point,color):
  cell_height=H/ROW
  cell_width=W/COL
  left=point.col*cell_width
  top=point.row*cell_height
  pygame.draw.rect(
    screen,color,
    (left,top,cell_width,cell_height)
  )

def display():                                                      #显示积分排行用的函数，其数据保存在游戏根目录中
  pygame.draw.rect(screen,(125,125,125),(250,100,300,400))
  show_text("得分排行榜:","SimHei",30,(255,255,255),260,130)
  with open('score.txt','r') as file_object:
    lines=file_object.readlines()
    num=list(map(int,lines))
    text1="top1."+' '+str(num[0])+'分'
    text2='top2.'+' '+str(num[1])+'分'
    text3='top3.'+' '+str(num[2])+'分'
    text4='top4.'+' '+str(num[3])+'分'
    text5='top5.'+' '+str(num[4])+'分'
    file_object.close()
  show_text(text1,"SimHei",28,(255,255,255),320,190)
  show_text(text2,"SimHei",28,(255,255,255),320,230)
  show_text(text3,"SimHei",28,(255,255,255),320,270)
  show_text(text4,"SimHei",28,(255,255,255),320,310)
  show_text(text5,"SimHei",28,(255,255,255),320,350)

#绘制play按钮的函数，因为参数过多，未集成
def button_rect():
  pygame.draw.rect(screen,(0,0,255),(280,250,200,50))
  font =pygame.font.Font(None,35)
  text="PLAY"
  score_render = font.render(text,True,(0,255,0))
  screen.blit (score_render,(350,265))
"完成游戏运行工作"

#分别四个bool控制游戏进行
quit = True         #quit 用来接收是否退出的信号
stop= True          #stop用来控制所有停止的情况。分为两部分，1.刚进游戏时默认为停止 2.死了 。但是两部分分开考虑
dead =False         #在stop的基础上描述是否死了
pause=False         #标记用户是否暂停了游戏。但不认为它在stop中，而认为是游戏进行中的一个部分
poisoning=False         #记录是否中毒，吃到紫色食物后会中毒（速度成为1.5倍），并持续六秒钟
nowtime=0.1             #记录从吃到紫色食物后的时间，以计算中毒持续时间
jud_display=False       #判定是否被召出排行榜

direct='left'            #标记当前运动方向，默认开始时向左运动
pygame.display.set_caption("贪吃蛇")
clock= pygame.time.Clock()

#游戏主循环
while quit : 
  #描述停止中时
  if stop:
    for event in pygame.event.get():
      position=pygame.mouse.get_pos()                 #记录鼠标范围
      if event.type == pygame.QUIT:
        quit=False
      elif (event.type == pygame.MOUSEBUTTONDOWN and
      position[0]<=480 and position[0]>=278  and        #若鼠标点击到play按钮范围，游戏开始，stop dead等状态清零
      position[1]>=248 and position[1]<=300):
        stop=False
        dead=False
      elif event.type ==pygame.KEYDOWN: 
          if event.key==283:                           #在stop阶段可以按F2召出排行榜
            if jud_display==False:
              jud_display=True
            else:
              jud_display=False              
            
    #渲染——画出来
    pygame.draw.rect(screen,bg_color,(0,0,W,H))
    show_score()
    show_text("按F1暂停/开始游戏","SimHei",25,(0,0,255),7,30)
    show_text("按F2打开/关闭排行榜","SimHei",25,(0,0,255),550,30)
    show_text("各种颜色食物的效果：","SimHei",20,(0,0,0),7,550)
    show_text("黄色","SimHei",20,(255,255,0),207,550)
    show_text("-普通","SimHei",20,(0,0,0),247,550)
    show_text("紫色","SimHei",20,(128,0,128),332,550)
    show_text("-中毒（速度增加50%）","SimHei",20,(0,0,0),372,550)
    show_text("红色","SimHei",20,(255,0,0),592,550)
    show_text("-迷惑（长度减半）","SimHei",20,(0,0,0),632,550)
    if score>649 and score<1500:                                    #在特定分数时进行特定显示的小彩蛋
        show_text("你真棒！","SimHei",25,(255,0,0),7,55)
    elif score>=1500:
      show_text("来S2楼625和628宿舍找我们！","SimHei",25,(255,0,0),7,55)
   
    rect(head,head_color)
    rect(food,food_color)
    button_rect()
    for Body in body:
      rect(Body,body_color)
    
    #死亡是停止的一个部分，分开讨论
    if dead:
      show_text("游戏结束了，请重新开始游戏","SimHei",50,(0,0,255),60,150)
    if jud_display:
      display()
    pygame.display.flip()
    clock.tick(20)

  #记录游戏开始时的内容
  else:
    #用户是否暂停
    if pause:
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          quit=False
        if event.type == pygame.KEYDOWN:
          if event.key ==282:
            pause=False

      #渲染——画出来
      pygame.draw.rect(screen,bg_color,(0,0,W,H))
      show_score()
      show_text("按F1暂停/开始游戏","SimHei",25,(0,0,255),7,30)
      if score>649 and score<1500:
        show_text("你真棒！","SimHei",25,(255,0,0),7,55)
      elif score>=1500:
        show_text("来S2楼625和628宿舍找我们！","SimHei",25,(255,0,0),7,55)
      rect(head,head_color)
      rect(food,food_color)
      for Body in body:
        rect(Body,body_color)
      pygame.display.flip()
      clock.tick(20)
    
    if not pause:
      
      body_color=(128,128,128)
      head_color=(0,128,128)

      if food_judge<=5:
        food_color=(255,255,0)   
      elif food_judge<=8:
        food_color=(128,0,128)
      else:
        food_color=(255,0,0)

      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          quit= False
        elif event.type ==pygame.KEYDOWN:
          if event.key==282:              #判定按到F1时开始暂停
            pause=True

          if direct=='up':
            if event.key==273 or event.key==119:
              direct="up"
            if event.key==276 or event.key==97:
              direct="left"
            if event.key==275 or event.key==100:
              direct="right"
          
          if direct=='down':
            if event.key==274 or event.key==115:
              direct="down"
            if event.key==276 or event.key==97:
              direct="left"
            if event.key==275 or event.key==100:
              direct="right"
          
          if direct=='left':
            if event.key==273 or event.key==119:
              direct="up"
            if event.key==274 or event.key==115:
              direct="down"
            if event.key==276 or event.key==97:
              direct="left"
          
          if direct=='right':
            if event.key==273 or event.key==119:
              direct="up"
            if event.key==274 or event.key==115:
              direct="down"
            if event.key==275 or event.key==100:
              direct="right"
          
      #渲染——画出来
      pygame.draw.rect(screen,bg_color,(0,0,W,H))
      rect(head,head_color)
      rect(food,food_color)
      show_score()
      show_text("按F1暂停/开始游戏","SimHei",25,(0,0,255),7,30)
      show_text("","SimHei",25,(0,0,255),7,30)
      show_text("","SimHei",25,(0,0,255),7,30)
      if score>649 and score<1500:
        show_text("你真棒！","SimHei",25,(255,0,0),7,55)
      elif score>=1500:
        show_text("来S2楼625和628宿舍找我们！","SimHei",25,(255,0,0),7,55)
      for Body in body:
        rect(Body,body_color)
      pygame.display.flip()
      eat =False
      
      if(head.row==food.row and head.col==food.col):              #判定吃到了食物，并进一步判定吃到食物的类型
        eat=True
        food = gen_food()
        score +=50
        if food_judge>5 and food_judge<=8:                        #food_judge的取值范围为0~9,0~5表示正常食物，6~8为紫色食物，9为红色
          poisoning=True                                  #为紫色时，进入中毒状态，记录当前时刻时间
          nowtime=time.time()
        elif food_judge==9:                               #当为红色食物时，长短减半，即body列表疯狂弹出至长度为之前的一半
          score-=100
          half_long=len(body)/2
          while len(body)>half_long:
            body.pop()
            if len(body)<1:
              dead=True
        food_judge=random.randint(0,9)                  #用以随机生成食物类型
      body.insert(0,head.copy())
      if eat==False:
        body.pop()

      
      if direct=='left':
        head.col-=1
      if direct=='right':
        head.col+=1
      if direct=='up':
        head.row-=1
      if direct=='down':
        head.row+=1

      "判定死亡"
      
      if head.row<0 or head.row>=ROW or head.col<0 or head.col>=COL:
        dead=True
      
      for Body in body:
        if head.row==Body.row and head.col==Body.col:
          dead=True
          break
      
      #若死亡，刷新设置
      if dead:
        poisoning=False
        stop=True
        dead=True
        head=Point(row=int(ROW/2),col=int(COL/2))
        body=[
          Point(row=head.row,col=head.col+1),
          Point(row=head.row,col=head.col+2),
          Point(row=head.row,col=head.col+3),
        ]
        direct='left'
        body_color=(255,255,255)
        head_color=(255,255,255)
        food_color=(255,255,255)

        with open('score.txt','r')as file_object:          #每次死亡时更新排行榜，首先打开文件读取以前的五个数据，再加上当前游戏分数，进行排序，取前五名
          lines=file_object.readlines()
          num=list(map(int,lines))
          num.append(score)
          num.sort(reverse=True)
          if len(num)==6:
            num.pop()
          file_object.close()
        with open('score.txt','w')as file_object:
          for data in num:
            file_object.write(str(data)+'\n')
          file_object.close()
        score=0
        food = gen_food()
        
      #设置帧率
      if poisoning:                   #判定中毒的时效，如果中毒事件超过6秒，中毒效果取消
        time1=time.time()
        if time1-nowtime>=6:
          poisoning=False
      v=20
      speed=7+score/60
      if speed>v:
        v=speed
      if poisoning:
        v=1.5*v                    #若中毒，速度为原来1.5倍
      clock.tick(v)
      
